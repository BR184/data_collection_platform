-- Approved completeness evidence for the unchanged frozen compatibility rows.
-- table: legacy_mysql_imported_tables, rows: 1
insert into legacy_mysql_imported_tables(table_name,record_count,last_synced_at,synced_at) select table_name,count(*),max(synced_at),max(synced_at) from legacy_mysql_imported_rows group by table_name;

-- Empty description is part of this controlled fixture, not evidence inferred in production.
insert into legacy_mongo_imported_collections(id,collection_name,record_count,last_synced_at,synced_at) values (3,'description',0,'2026-09-01T13:22:08'::timestamp,'2026-09-01T13:22:08'::timestamp);

select setval(pg_get_serial_sequence('legacy_mongo_imported_collections','id'),(select max(id) from legacy_mongo_imported_collections));
select setval(pg_get_serial_sequence('legacy_mysql_imported_tables','id'),(select max(id) from legacy_mysql_imported_tables));
